﻿using System.Collections.Generic;

public interface Idetails
{
    void DisplayAllStates(List<State> states);
    State SearchStateByAreaCode(List<State> states, string areaCode);
    void AddState(List<State> states, State state);
}
